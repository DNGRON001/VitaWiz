var cvColour = "Initial";


function Red() {
    document.getElementById("left").style.background = "linear-gradient(to top right, #ee5e4b, #ec988d)";
    document.getElementById("sign").style.color = "#ee5e4b";
    document.getElementById("phone").style.color = "#ee5e4b";
    document.getElementById("email").style.color = "#ee5e4b";
    document.getElementById("about").style.color = "#ee5e4b";
    document.getElementById("work").style.color = "#ee5e4b";
    document.getElementById("qual").style.color = "#ee5e4b";
    document.getElementById("documents").style.color = "#ee5e4b";
    document.getElementById("aboutborder").style.borderBottom = "2px solid #ee5e4b";
    document.getElementById("workborder").style.borderBottom = "2px solid #ee5e4b";
    document.getElementById("qualborder").style.borderBottom = "2px solid #ee5e4b";
    document.getElementById("docborder").style.borderBottom = "2px solid #ee5e4b";
    cvColour = "Red";
}

function Orange() {
    document.getElementById("left").style.background = "linear-gradient(to top right, #e6962fec, #f5d1a9)";
    document.getElementById("sign").style.color = "#e6962fec";
    document.getElementById("phone").style.color = "#e6962fec";
    document.getElementById("email").style.color = "#e6962fec";
    document.getElementById("about").style.color = "#e6962fec";
    document.getElementById("work").style.color = "#e6962fec";
    document.getElementById("qual").style.color = "#e6962fec";
    document.getElementById("documents").style.color = "#e6962fec";
    document.getElementById("aboutborder").style.borderBottom = "2px solid #e6962fec";
    document.getElementById("workborder").style.borderBottom = "2px solid #e6962fec";
    document.getElementById("qualborder").style.borderBottom = "2px solid #e6962fec";
    document.getElementById("docborder").style.borderBottom = "2px solid #e6962fec";
    cvColour = "Orange";
}

function Yellow() {
    document.getElementById("left").style.background = "linear-gradient(to top right, #b1af37, #bbc93e)";
    document.getElementById("sign").style.color = "#b1af37";
    document.getElementById("phone").style.color = "#b1af37";
    document.getElementById("email").style.color = "#b1af37";
    document.getElementById("about").style.color = "#c2c03c";
    document.getElementById("work").style.color = "#c2c03c";
    document.getElementById("qual").style.color = "#c2c03c";
    document.getElementById("documents").style.color = "#c2c03c";
    document.getElementById("aboutborder").style.borderBottom = "2px solid #b1af37";
    document.getElementById("workborder").style.borderBottom = "2px solid #b1af37";
    document.getElementById("qualborder").style.borderBottom = "2px solid #b1af37";
    document.getElementById("docborder").style.borderBottom = "2px solid #b1af37";
    cvColour = "Yellow";
}

function Green() {
    document.getElementById("left").style.background = "linear-gradient(to top right, #22e02bcb, #61e978)";
    document.getElementById("sign").style.color = "#22e02bcb";
    document.getElementById("phone").style.color = "#22e02bcb";
    document.getElementById("email").style.color = "#22e02bcb";
    document.getElementById("about").style.color = "#09b111cb";
    document.getElementById("work").style.color = "#09b111cb";
    document.getElementById("qual").style.color = "#09b111cb";
    document.getElementById("documents").style.color = "#22e02bcb";
    document.getElementById("aboutborder").style.borderBottom = "2px solid #09b111cb";
    document.getElementById("workborder").style.borderBottom = "2px solid #09b111cb";
    document.getElementById("qualborder").style.borderBottom = "2px solid #09b111cb";
    document.getElementById("docborder").style.borderBottom = "2px solid #09b111cb";
    cvColour = "Green";
}

function Blue() {
    document.getElementById("left").style.background = "linear-gradient(to top right, #4c72f0, #657ff1)";
    document.getElementById("sign").style.color = "#4c72f0";
    document.getElementById("phone").style.color = "#4c72f0";
    document.getElementById("email").style.color = "#4c72f0";
    document.getElementById("about").style.color = "#4c72f0";
    document.getElementById("work").style.color = "#4c72f0";
    document.getElementById("qual").style.color = "#4c72f0";
    document.getElementById("documents").style.color = "#4c72f0";
    document.getElementById("aboutborder").style.borderBottom = "2px solid #4c72f0";
    document.getElementById("workborder").style.borderBottom = "2px solid #4c72f0";
    document.getElementById("qualborder").style.borderBottom = "2px solid #4c72f0";
    document.getElementById("docborder").style.borderBottom = "2px solid #4c72f0";
    cvColour = "Blue";
}

function Purple() {
    getID("redbutton").setAttribute(active, false);
    getID("greenbutton").setAttribute(active, false);

    document.getElementById("left").style.backgroundImage = "linear-gradient(to top right, #b861ff, #bbbbbb)";
    document.getElementById("sign").style.color = "#b861ff";
    document.getElementById("phone").style.color = "#b861ff";
    document.getElementById("email").style.color = "#b861ff";
    document.getElementById("about").style.color = "#b861ff";
    document.getElementById("work").style.color = "#b861ff";
    document.getElementById("qual").style.color = "#b861ff";
    document.getElementById("documents").style.color = "#b861ff";
    document.getElementById("aboutborder").style.borderBottom = "2px solid #b861ff";
    document.getElementById("workborder").style.borderBottom = "2px solid #b861ff";
    document.getElementById("qualborder").style.borderBottom = "2px solid #b861ff";
    /* document.getElementById("docborder").style.borderBottom = "2px solid #b861ff"; */
    cvColour = "Purple";
    var button = document.getElementById("purplebutton");
    button.setAttribute("active", true);
}


function Reset() {
    document.getElementById("left").style.backgroundImage = "linear-gradient(to top right, #b861ff, #bbbbbb)";
    document.getElementById("sign").style.color = "#b861ff";
    document.getElementById("phone").style.color = "#b861ff";
    document.getElementById("email").style.color = "#b861ff";
    document.getElementById("about").style.color = "#b861ff";
    document.getElementById("work").style.color = "#b861ff";
    document.getElementById("qual").style.color = "#b861ff";
    document.getElementById("documents").style.color = "#b861ff";
    document.getElementById("aboutborder").style.borderBottom = "2px solid #b861ff";
    document.getElementById("workborder").style.borderBottom = "2px solid #b861ff";
    document.getElementById("qualborder").style.borderBottom = "2px solid #b861ff";
    document.getElementById("docborder").style.borderBottom = "2px solid #b861ff";
    cvColour = "Initial";
}
function getID (n){
    var element = document.getElementById(n)
    return element
}
/* document.addEventListener("#next", passparameter(){
    if ((document.getElementById('redbutton').active)== true) {
        var url = "createCV.html"
        window.location = url + "?red" + "&"+ uid + "&"+ jobrole
    }
}); */