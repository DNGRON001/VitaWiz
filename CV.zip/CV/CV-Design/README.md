# First CV design for VitaWiz

Colourful template(s) for users to select from
3-4 appealing colour schemes to select 

