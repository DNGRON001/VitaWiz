const firebaseConfig = {
    apiKey: "AIzaSyDXi_12SEDRpiCwwLnRGB0NxJ7hb-jcM4k",
    authDomain: "vitawiz.firebaseapp.com",
    databaseURL: "https://vitawiz.firebaseio.com",
    projectId: "vitawiz",
    storageBucket: "vitawiz.appspot.com",
    messagingSenderId: "1030056848309",
    appId: "1:1030056848309:web:55888e17198e4eb4db07fc",
    measurementId: "G-6PM1731QQL"
};

const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();